LEARN SPHERE — CUSTOMIZED FREE BLOG

PREVIEW
1. Extract this ZIP on your laptop.
2. Open index.html in Chrome, Edge, Firefox or another browser.

EDIT
- Search for `const articles = [` near the bottom of index.html to edit/add articles.
- Each article has title, category, readTime, description, and body fields.
- Categories for the filter: Careers, Finance, Commerce, Skills.
- Replace hello@example.com with your email address before publishing.

PUBLISH FREE USING GITHUB PAGES
1. Sign in at https://github.com/
2. Create a new PUBLIC repository, for example `learnsphere-blog`.
3. Upload index.html to the repository's top level.
4. Open Settings -> Pages.
5. Select Deploy from a branch, choose `main` and `/(root)`, then Save.
6. GitHub Pages will show the website URL when it is published. It usually resembles:
   https://YOUR-USERNAME.github.io/learnsphere-blog/

NOTES
- GitHub Pages hosts static websites for free; it does not provide a database or server-side backend.
- The topic-suggestion button opens a visitor's email app; it does not collect email addresses.
- Do not put passwords, API keys, or private information in a public repository.
- Review educational and financial information before publishing.
